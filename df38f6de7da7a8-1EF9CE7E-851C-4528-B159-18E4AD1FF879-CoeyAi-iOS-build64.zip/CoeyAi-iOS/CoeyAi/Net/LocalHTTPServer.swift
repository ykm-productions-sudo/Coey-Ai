import Foundation
import Network

/// A tiny loopback HTTP server that serves the Coey Ai web bundle.
///
/// The bundle is served over http://127.0.0.1:<port> rather than file://
/// because WebKit disables localStorage / module scripts on file URLs.
/// The port is fixed so the origin (and therefore the saved PIN, chats
/// and API key) survives relaunches.
final class LocalHTTPServer {

    enum ServerError: Error, LocalizedError {
        case couldNotStart

        var errorDescription: String? { "The local web server could not start." }
    }

    private let root: URL
    private let queue = DispatchQueue(label: "ai.coey.http", qos: .userInitiated)
    private var listener: NWListener?
    private(set) var port: UInt16 = 0

    private static let preferredPorts: [UInt16] = [8765, 8766, 8767, 8768, 8769]

    init(root: URL) {
        self.root = root
    }

    deinit {
        listener?.cancel()
    }

    func start() throws -> UInt16 {
        if let listener, port != 0 {
            _ = listener
            return port
        }

        for candidate in Self.preferredPorts {
            if let ready = try? startListener(on: candidate) {
                listener = ready
                port = candidate
                return candidate
            }
        }
        throw ServerError.couldNotStart
    }

    private func startListener(on candidate: UInt16) throws -> NWListener {
        guard let nwPort = NWEndpoint.Port(rawValue: candidate) else {
            throw ServerError.couldNotStart
        }

        let params = NWParameters.tcp
        params.allowLocalEndpointReuse = true
        params.requiredLocalEndpoint = NWEndpoint.hostPort(
            host: .ipv4(.loopback),
            port: nwPort
        )

        let listener = try NWListener(using: params)

        let ready = DispatchSemaphore(value: 0)
        var didBecomeReady = false

        listener.stateUpdateHandler = { state in
            switch state {
            case .ready:
                didBecomeReady = true
                ready.signal()
            case .failed, .cancelled:
                ready.signal()
            default:
                break
            }
        }
        listener.newConnectionHandler = { [weak self] connection in
            self?.handle(connection)
        }
        listener.start(queue: queue)

        if ready.wait(timeout: .now() + 4) == .timedOut || !didBecomeReady {
            listener.cancel()
            throw ServerError.couldNotStart
        }
        return listener
    }

    func stop() {
        listener?.cancel()
        listener = nil
        port = 0
    }

    // MARK: - Connections

    private func handle(_ connection: NWConnection) {
        connection.start(queue: queue)
        receive(on: connection, buffer: Data())
    }

    private func receive(on connection: NWConnection, buffer: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) {
            [weak self] data, _, isComplete, error in
            guard let self else {
                connection.cancel()
                return
            }

            var buffer = buffer
            if let data, !data.isEmpty {
                buffer.append(data)
            }

            if let headerEnd = buffer.range(of: Data("\r\n\r\n".utf8)) {
                let head = String(decoding: buffer[..<headerEnd.lowerBound], as: UTF8.self)
                self.respond(on: connection, head: head)
                return
            }

            if isComplete || error != nil || buffer.count > 128 * 1024 {
                connection.cancel()
                return
            }
            self.receive(on: connection, buffer: buffer)
        }
    }

    private func respond(on connection: NWConnection, head: String) {
        let lines = head.components(separatedBy: "\r\n")
        guard let requestLine = lines.first else {
            sendText("400 Bad Request", status: "400 Bad Request", on: connection)
            return
        }

        let parts = requestLine.split(separator: " ")
        guard parts.count >= 2 else {
            sendText("400 Bad Request", status: "400 Bad Request", on: connection)
            return
        }

        let method = String(parts[0]).uppercased()
        guard method == "GET" || method == "HEAD" else {
            sendText("405 Method Not Allowed", status: "405 Method Not Allowed", on: connection)
            return
        }

        var headers: [String: String] = [:]
        for line in lines.dropFirst() {
            guard let colon = line.firstIndex(of: ":") else { continue }
            let name = line[..<colon].trimmingCharacters(in: .whitespaces).lowercased()
            let value = line[line.index(after: colon)...].trimmingCharacters(in: .whitespaces)
            headers[name] = value
        }

        let rawPath = String(parts[1])
        let pathOnly = rawPath.split(separator: "?", maxSplits: 1).first.map(String.init) ?? "/"
        var relative = pathOnly.removingPercentEncoding ?? pathOnly
        if relative.hasPrefix("/") { relative.removeFirst() }
        if relative.isEmpty { relative = "index.html" }
        if relative.contains("..") {
            sendText("403 Forbidden", status: "403 Forbidden", on: connection)
            return
        }

        let fileURL = root.appendingPathComponent(relative)
        guard let attributes = try? FileManager.default.attributesOfItem(atPath: fileURL.path),
              let sizeNumber = attributes[.size] as? NSNumber else {
            sendText("404 Not Found", status: "404 Not Found", on: connection)
            return
        }

        let size = sizeNumber.intValue
        let mime = Self.mimeType(for: fileURL.pathExtension)
        let cache = relative.hasSuffix(".html") || relative.hasSuffix(".js")
            ? "no-store"
            : "public, max-age=86400"

        var status = "200 OK"
        var rangeStart = 0
        var rangeLength = size
        var contentLength = size

        if let rangeHeader = headers["range"],
           let parsed = Self.parseRange(rangeHeader, size: size) {
            status = "206 Partial Content"
            rangeStart = parsed.0
            rangeLength = parsed.1 - parsed.0 + 1
            contentLength = rangeLength
        }

        var responseHead = "HTTP/1.1 \(status)\r\n"
        responseHead += "Content-Type: \(mime)\r\n"
        responseHead += "Content-Length: \(contentLength)\r\n"
        responseHead += "Accept-Ranges: bytes\r\n"
        responseHead += "Cache-Control: \(cache)\r\n"
        responseHead += "Connection: close\r\n"
        if status == "206 Partial Content" {
            responseHead += "Content-Range: bytes \(rangeStart)-\(rangeStart + rangeLength - 1)/\(size)\r\n"
        }
        responseHead += "\r\n"

        var payload = Data(responseHead.utf8)

        if method == "GET" {
            if let handle = try? FileHandle(forReadingFrom: fileURL) {
                defer { try? handle.close() }
                if rangeStart > 0 { try? handle.seek(toOffset: UInt64(rangeStart)) }
                if let body = try? handle.read(upToCount: rangeLength) {
                    payload.append(body)
                }
            } else {
                sendText("500 Internal Server Error", status: "500 Internal Server Error", on: connection)
                return
            }
        }

        connection.send(content: payload, completion: .contentProcessed { _ in
            connection.cancel()
        })
    }

    private func sendText(_ text: String, status: String, on connection: NWConnection) {
        let body = Data(text.utf8)
        var head = "HTTP/1.1 \(status)\r\n"
        head += "Content-Type: text/plain; charset=utf-8\r\n"
        head += "Content-Length: \(body.count)\r\n"
        head += "Connection: close\r\n\r\n"
        var payload = Data(head.utf8)
        payload.append(body)
        connection.send(content: payload, completion: .contentProcessed { _ in
            connection.cancel()
        })
    }

    // MARK: - Helpers

    private static func parseRange(_ value: String, size: Int) -> (Int, Int)? {
        let lowered = value.lowercased()
        guard lowered.hasPrefix("bytes="), size > 0 else { return nil }

        let spec = lowered.dropFirst("bytes=".count).split(separator: ",").first.map(String.init) ?? ""
        let bounds = spec.split(separator: "-", omittingEmptySubsequences: false)
        guard bounds.count == 2 else { return nil }

        let startText = String(bounds[0])
        let endText = String(bounds[1])

        if startText.isEmpty {
            guard let suffix = Int(endText), suffix > 0 else { return nil }
            let start = max(0, size - suffix)
            return (start, size - 1)
        }

        guard let start = Int(startText), start >= 0, start < size else { return nil }
        if endText.isEmpty { return (start, size - 1) }
        guard let end = Int(endText) else { return nil }
        return (start, min(end, size - 1))
    }

    private static func mimeType(for ext: String) -> String {
        switch ext.lowercased() {
        case "html", "htm": return "text/html; charset=utf-8"
        case "js", "mjs": return "text/javascript; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "json": return "application/json; charset=utf-8"
        case "mp4", "m4v": return "video/mp4"
        case "webm": return "video/webm"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "webp": return "image/webp"
        case "svg": return "image/svg+xml"
        case "ico": return "image/x-icon"
        case "wasm": return "application/wasm"
        case "woff": return "font/woff"
        case "woff2": return "font/woff2"
        case "ttf": return "font/ttf"
        default: return "application/octet-stream"
        }
    }
}
